# Tools Used for the Project


1. [VS Code](https://code.visualstudio.com/)

    For writing the create commmands and the readme file.


2. [Lucid Chart](https://lucid.app/)

    For creating the ER diagram.


3. [iTerm2 Terminal](https://iterm2.com/)

    To run the SQL commands.


4. [Screenshot App shottr on macOS](https://shottr.cc/)

    To take screenshots of the SQL commands.


5. [sqlite3](https://www.sqlite.org/index.html)

    To run the SQL commands.


6. [Google Chrome](https://www.google.com/chrome/)

    To collaborate with team members as well as use lucid chart.


7. [Google Docs](https://docs.google.com/)

    To collaborate with team members on a shared document while writng the SQL queries and compiling all the information.


8. [Microsoft Teams](https://www.microsoft.com/en-us/microsoft-teams/group-chat-software)

    To collaborate with team members virtually on audio and video call as well as sharing documents.



