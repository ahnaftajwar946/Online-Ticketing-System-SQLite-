INSERT INTO MOVIE(Movie_id,Movie_title,Movie_duration) VALUES
(1,'The Shawshank Redemption',142),
(2,'The Wizard of Oz',102),
(3,'Vertigo',128),
(4,'Forrest Gump',142),
(5,'The Sound of Music',172),
(6,'Gladiator',155);


INSERT INTO CINEMA(Cinema_id,City_id,Cinema_name) VALUES
(1,1,'Cinemaprism'),
(2,2,'Cinemaque'),
(3,3,'Fuze Cinema'),
(4,1,'Crowd Cinema');

INSERT INTO SCREEN(Movie_id,Cinema_id,Screen_id,Screen_time) VALUES
(1,1,1,'12 pm - 2 pm'),
(1,2,1,'2 pm - 4 pm'),
(2,3,2,'2 pm - 4 pm'),
(2,4,2,'12 pm - 2 pm'),
(3,1,3,'4 pm - 6 pm'),
(4,1,3,'2 pm - 4 pm'),
(4,1,1,'4 pm - 6 pm'),
(4,2,2,'12 pm - 2 pm'),
(5,2,3,'2 pm - 4 pm'),
(5,3,1,'2 pm - 4 pm'),
(6,3,1,'4 pm - 6 pm'),
(6,4,2,'2 pm - 4 pm'),
(6,4,3,'2 pm - 4 pm'),
(6,1,3,'12 pm - 2 pm');

INSERT INTO CITY(City_id,City_name) VALUES
(1,'Dallas'),
(2,'Fort Worth'),
(3,'Arlington');

INSERT INTO BOOKING(BT_ID,Movie_id,Cinema_id,Screen_id,SeatNum) VALUES
(1,1,1,1,1),
(2,1,2,1,1),
(3,2,3,2,1),
(4,2,4,2,1),
(5,3,1,3,1),
(6,4,1,3,1),
(7,4,1,1,1),
(8,4,2,2,1),
(9,5,2,3,1),
(10,5,3,1,1),
(11,6,3,1,1),
(12,6,4,2,2),
(13,6,4,3,2),
(14,6,1,3,2),
(15,1,1,1,2),
(16,1,2,1,2),
(17,2,3,2,2),
(18,2,4,2,3),
(19,3,1,3,3),
(20,4,1,3,3),
(21,4,1,1,3),
(22,4,2,2,3),
(23,5,2,3,3),
(24,5,3,1,3),
(25,6,3,1,3),
(26,6,4,2,4),
(27,6,4,3,4),
(28,6,1,3,4);

