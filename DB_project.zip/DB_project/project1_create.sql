create table CITY(
    City_id int NOT NULL ,
    City_name varchar(50) NOT NULL, 
    PRIMARY KEY (City_id)
    
create table MOVIE(
    Movie_id int NOT NULL,
    Movie_title varchar(50) NOT NULL,
    Movie_duration int NOT NULL,
    PRIMARY KEY (Movie_id)
    );

create table CINEMA(
    Cinema_id int NOT NULL,
    City_id int NOT NULL,
    Cinema_name varchar(50) NOT NULL,
    PRIMARY KEY (Cinema_id)
    FOREIGN KEY (City_id) REFERENCES CITY(City_id)
    UNIQUE (Cinema_name)
    );
    
create table BOOKING(
    BT_ID int NOT NULL,
    Movie_id int,
    Cinema_id int,
    Screen_id date NOT NULL,
    SeatNum int NOT NULL,
    PRIMARY KEY (BT_ID),
    FOREIGN KEY (Movie_id, Cinema_id) REFERENCES SCREEN(Movie_id, Cinema_id)
    );

create table SCREEN(
    Movie_id int,
    Cinema_id int,
    Screen_id int NOT NULL,
    Screen_time time NOT NULL,
    FOREIGN KEY (Movie_id, Cinema_id) REFERENCES BOOKING(Movie_id, Cinema_id)
    );

